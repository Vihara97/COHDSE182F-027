<html>
<head><title>Login</title></head>
<body>
	<form name="Login" method="POST" action="#">
		Username <input type="text" name="txtUn" value="test"/><br/><br/>
		Password <input type="password" name="txtPwd" value="1234"/><br/><br/>
		<input type="submit" name="btnLogin" value="Login" /><br/>		

	</form>
</body>
</html>

<?php
if(isset($_REQUEST["txtUn"]))
{
	$un = $_REQUEST["txtUn"];
	$pwd = md5($_REQUEST["txtPwd"]);
	//connect with mysql
	$con=mysqli_connect("localhost","cohdse182f-027","123");
	//select database
	mysqli_select_db($con,"student");
	//command
	$sql = "select * from login";
	
	$result = mysqli_query($con,$sql);

	while($row = mysqli_fetch_array($result))
	{	
		if($un == $row[0] && $pwd == $row[1])
		{
			session_start();
			$_SESSION["txtUn"] = $uname;
			$_SESSION["txtPwd"] = $pass;
			$_SESSION["LAT"] = time();
			header("location:welcome.php");

		}
		else
		{
			echo "invalid username or password";
		}
	}
		
	
	
	mysqli_close($con);

}
?>
