<html>
<head>
	<title>Welcome</title>
</head>

<body>
 
<?php
session_start();
if(time() - $_SESSION["LAT"] <= 10)
{	$_SESSION["LAT"] = time();
	echo "<h1>Welcome User!</h1>";
	//session_destroy();
}
else
{   header("location:login.php");}
?>
</body>
</html>

