import pymongo
import hashlib

print("____________________LOGIN____________________")
print("")

un = input("Enter username ")
pwd = input("Enter password ")

def hash_password(password):
   return hashlib.md5(password.encode()).hexdigest()

hashed_password = hash_password(pwd)

uri = "mongodb://127.0.0.1:27017"
client = pymongo.MongoClient(uri)
database = client['Student']
collection = database['Log']

Log = collection.find({})

for user in Log:
    if un == user['username'] and hashed_password == user['password']:
        print("Login successful")
    else:
        print("Incorrect username or password!")
