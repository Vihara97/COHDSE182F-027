from pymongo import MongoClient
Client = MongoClient()
db = Client['Student']
collection = db['Log']
user = {}
user['username']="user1"
user['password']="b24331b1a138cde62aa1f679164fc62f"
collection.insert(user)
print(user)
